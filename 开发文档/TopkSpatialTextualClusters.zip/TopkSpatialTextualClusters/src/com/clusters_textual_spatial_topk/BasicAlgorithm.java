package com.clusters_textual_spatial_topk;


public class BasicAlgorithm {

}
